﻿using SampleLibrary.Interfaces;

namespace SampleLibrary;

public class ConsoleOutput : IOutPut
{
    public void OutPut(string output)
    {
        Console.WriteLine(output);
    }
}