﻿namespace SampleLibrary;

public class Program
{
    public static void Main(string[] args)
    {
        new Manager(new ConsoleOutput(), new ConsoleInput()).Run();
    }
}
