﻿namespace SampleLibrary.Interfaces;

public interface IOutPut
{
    public void OutPut(string stringToPrint);
}