﻿namespace SampleLibrary.Interfaces;

public interface Ix
{

    public string Format(string str);
}