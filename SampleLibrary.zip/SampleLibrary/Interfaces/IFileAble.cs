﻿namespace SampleLibrary.Interfaces;

public interface IFileAble
{
    public string[] GetListOfFiles();

    public string GetFileName(int numberOfCurrentFile);
    
}