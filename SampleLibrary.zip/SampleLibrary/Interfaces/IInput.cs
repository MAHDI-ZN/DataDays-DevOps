﻿namespace SampleLibrary.Interfaces;

public interface IInput
{
    public string Read();
}