﻿using SampleLibrary.Interfaces;

namespace SampleLibrary;

public class ConsoleInput : IInput
{
    public string Read()
    {
        return Console.ReadLine();
    }   
}