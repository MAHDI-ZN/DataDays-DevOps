﻿using SampleLibrary.Interfaces;

namespace SampleLibrary;

public class DataSet : IReadAble, IWriteAble
{
    private readonly Dictionary<string, Dictionary<int, int>> _dataset;

    public DataSet()
    {
        _dataset = new Dictionary<string, Dictionary<int, int>>();
    }
    
    public void Write(string key, int numberOfCurrentFile)
    {
        if (!_dataset.ContainsKey(key))
        {
            var temporary = new Dictionary<int, int>();
            _dataset.Add(key, temporary);
        }
        var countByFiles = _dataset[key];
        if(!countByFiles.ContainsKey(numberOfCurrentFile)){
            countByFiles.Add(numberOfCurrentFile, 0);
        }
        countByFiles[numberOfCurrentFile] += 1;
    }

    public Dictionary<int, int> Read(string key)
    {
        return _dataset[key];
    }
}