using NSubstitute;
using SampleLibrary.Interfaces;

namespace SampleLibrary.Test;

public class UnitTest1
{
    [Fact]
    public void ManagerPrintTest()
    {
        var output = Substitute.For<IOutPut>();
        var input = Substitute.For<IInput>();
        var manager = new Manager(output, input);
        
        manager.Run();

        output.Received().OutPut(Arg.Any<string>());
    }

    [Fact]
    public void ManagerInputTest()
    {
        var input = Substitute.For<IInput>();
        var output = Substitute.For<IOutPut>();
        var manager = new Manager(output, input);
        
        manager.Run();

        input.Received().Read();
    }
}