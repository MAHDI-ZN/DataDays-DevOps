﻿using NSubstitute;
using SampleLibrary.Interfaces;

namespace SampleLibrary.Test;

public class FileHandlerTest
{
    [Theory]
    [InlineData(".//TestFolder",".//TestFolder\\.txt",".//TestFolder\\a.txt")]
    public void GetFileNameTest(string pathToFile, string firstFileName, string secondFileName)
    {
        var fileHandler = new FileHandler(pathToFile);

        Assert.Equal(firstFileName, fileHandler.GetFileName(0));
        Assert.Equal(secondFileName, fileHandler.GetFileName(1));

    }
    
    public void G
}