﻿using System.Runtime.Serialization;
using NSubstitute;
using SampleLibrary.Interfaces;
using Xunit;

namespace lsfjdslk
{


    public interface ICommand
    {
        void Execute();
        event EventHandler Executed;
    }

    public class SomethingThatNeedsACommand
    {
        ICommand command;

        public SomethingThatNeedsACommand(ICommand command)
        {
            this.command = command;
        }

        public void DoSomething()
        {
            command.Execute();
        }

        public void DontDoAnything()
        {
        }
    }

    public class a
    {

        [Fact]
        public void Should_execute_command()
        { 
        var formatter = Substitute.For<Ix>();
        formatter.Format(Arg.Is<string>(x => x.Length <= 10)).Returns("matched");

        Assert.Equal("matched", formatter.Format("short"));
        Assert.NotEqual("matched", formatter.Format("not matched, too long"));
// Will not match because trying to access .Length on null will throw an exception when testing
// our condition. NSubstitute will assume it does not match and swallow the exception.
        Assert.NotEqual("matched", formatter.Format(null));
        }


    }
}