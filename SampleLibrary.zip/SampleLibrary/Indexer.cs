﻿namespace SampleLibrary;

public class Indexer
{
    
}