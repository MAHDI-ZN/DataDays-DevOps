﻿using SampleLibrary.Interfaces;

namespace SampleLibrary;

public class Manager
{
    private readonly IOutPut _outPut;
    private readonly IInput _input;

    public Manager(IOutPut outPut, IInput input)
    {
        _outPut = outPut;
        _input = input;
    }

    public void Run()
    {
        PrintWelcomeMessage(_outPut);

        var pathToFile = InputPath(_input);

        var dataSet = new DataSet();
        
        
    }

    private void PrintWelcomeMessage(IOutPut output)
    {
        output.OutPut("HI\nEnter Directory Path:");
    }

    private string InputPath(IInput input)
    {
        return input.Read();
    }
}